package sbmscripts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbmScriptsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbmScriptsApplication.class, args);
	}

}
